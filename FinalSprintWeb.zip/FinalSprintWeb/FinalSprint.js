incomeTaxRate = 0.17;
//  Function to read the JSON file and iterate through the array

// Read the file from disk
fetch('./people.json')
// The file is convert to JSON
    .then(response => response.json())
    // Put date into name variable (people)   
    .then(people => {
        // Create a container to hold the people data
        let container = document.createElement('div');
        container.id = 'peopleContainer';
        // Iterate through the array using forEach
        people.forEach(record => {
          // Create a new div for each person
          let person = document.createElement('div');
          person.className = 'person';

          // Add the person's data to the div
          person.innerHTML = `
            <h2>${getFullName(record)}</h2>
            <p> ${getAge(record)}</p>
            <p>${getGender(record)}</p>
            <p>Salary: ${getSalary(record)}</p>
            <p>Income Tax: ${getIncomeTax(record)}</p>
            <p>Net Income: ${getNetIncome(record)}</p>
           
          `;
         // Add the person's div to the container
          container.appendChild(person);

          // Display one message while accessing each array object
          console.log(`${getFullName(record)}`);
          console.log(`${getGender(record)}`);
          console.log(`${getAge(record)}`);
          console.log(`${getNetIncome(record)}`);
        });
        // Add the container to the document
        document.body.appendChild(container);
      })
      .catch(error => {
        console.error(error);
    });

      function getFullName(person) {
        return `${person.firstName} ${person.lastName}`;
      }
    
      function getAge(person) {    
        return `${person.firstName} ${person.lastName} is ${new Date().getFullYear() - 
          new Date(person.birthday).getFullYear()} years old.`; 
      }
    
      function getGender(person){
        return `${person.firstName} ${person.lastName} is ${person.gender}.` || person.gender;
      }
    
      function getSalary(person){
        return person.salary;
      }
    
      function getIncomeTax(person){
        return person.salary * incomeTaxRate;
      }
    
      function getNetIncome(person){
        return `has a yearly salary of ${person.salary - getIncomeTax(person)}.`;
      }